HRT MDG1 RSA Patcher - Build-Anleitung
================================================

INHALT DIESES PAKETS:
- patch_bytes_gui.py               -> Hauptprogramm (GUI, Logo eingebettet,
                                       erkennt automatisch Deutsch/Englisch)
- HRT_MDG1_RSA_Patcher_icon.ico     -> Icon fuer die .exe
- HRT_MDG1_RSA_Patcher_starten.bat  -> Startet das Programm ohne exe (per Python)

SPRACH-ERKENNUNG:
------------------
Das Programm erkennt automatisch die Systemsprache. Ist das Windows-System
auf Deutsch eingestellt, erscheint die Oberflaeche auf Deutsch. Bei jeder
anderen Systemsprache erscheint die Oberflaeche auf Englisch als Standard.


OPTION A: Direkt per Batch-Datei starten (kein Build noetig)
--------------------------------------------------------------
Einfach HRT_MDG1_RSA_Patcher_starten.bat per Doppelklick ausfuehren.
Python wird bei Bedarf automatisch installiert.


OPTION B: Zu einer eigenstaendigen .exe kompilieren (Windows)
--------------------------------------------------------------
1. Python installieren (https://www.python.org/downloads/), beim Setup
   "Add python.exe to PATH" aktivieren.

2. PyInstaller installieren:
   pip install pyinstaller

3. In diesem Ordner (mit allen Dateien) folgenden Befehl ausfuehren:

   pyinstaller --onefile --windowed --icon=HRT_MDG1_RSA_Patcher_icon.ico --name "HRT_MDG1_RSA_Patcher" patch_bytes_gui.py

4. Fertige Datei liegt danach in:
   dist\HRT_MDG1_RSA_Patcher.exe

5. Die Ordner "build" und "__pycache__" sowie die Datei
   "HRT_MDG1_RSA_Patcher.spec" koennen danach geloescht werden,
   benoetigt wird nur dist\HRT_MDG1_RSA_Patcher.exe
