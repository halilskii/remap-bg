@echo off
REM Startet den Hibert Performance RSA Patch (patch_bytes_gui.py) ohne Konsolenfenster.
REM Installiert Python automatisch, falls es fehlt.
REM Diese .bat muss im selben Ordner wie patch_bytes_gui.py liegen.

title HRT MDG1 RSA Patcher
cd /d "%~dp0"

if not exist "patch_bytes_gui.py" (
    echo FEHLER: patch_bytes_gui.py wurde nicht im selben Ordner gefunden.
    echo Aktueller Ordner: %cd%
    pause
    exit /b 1
)

call :find_python
if "%PY_CMD%"=="" (
    echo Python wurde nicht gefunden. Es wird automatisch installiert...
    call :install_python
    call :find_python
)

if "%PY_CMD%"=="" (
    echo.
    echo ============================================================
    echo Die automatische Installation ist fehlgeschlagen.
    echo Bitte installiere Python manuell von:
    echo   https://www.python.org/downloads/
    echo und aktiviere beim Setup "Add python.exe to PATH".
    echo ============================================================
    pause
    exit /b 1
)

start "" /B %PY_CMD% patch_bytes_gui.py
exit /b 0


:find_python
set "PY_CMD="
where pythonw >nul 2>nul
if %errorlevel%==0 (
    pythonw --version >nul 2>nul
    if %errorlevel%==0 (
        set "PY_CMD=pythonw"
        goto :eof
    )
)
python --version >nul 2>nul
if %errorlevel%==0 (
    set "PY_CMD=python"
    goto :eof
)
py --version >nul 2>nul
if %errorlevel%==0 (
    set "PY_CMD=py"
    goto :eof
)
goto :eof


:install_python
echo Lade Python-Installer herunter (benoetigt Internetverbindung)...

where winget >nul 2>nul
if %errorlevel%==0 (
    winget install -e --id Python.Python.3.12 --scope machine --silent --accept-package-agreements --accept-source-agreements
    if %errorlevel%==0 (
        for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set "SYS_PATH=%%B"
        for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "USER_PATH=%%B"
        set "PATH=%SYS_PATH%;%USER_PATH%;%PATH%"
        goto :eof
    )
)

set "PY_INSTALLER=%TEMP%\python_installer.exe"
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%PY_INSTALLER%'"
if not exist "%PY_INSTALLER%" (
    echo Download fehlgeschlagen.
    goto :eof
)

echo Installiere Python still im Hintergrund, bitte warten...
"%PY_INSTALLER%" /quiet InstallAllUsers=1 PrependPath=1 Include_test=0
del "%PY_INSTALLER%" >nul 2>nul

for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set "SYS_PATH=%%B"
for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "USER_PATH=%%B"
set "PATH=%SYS_PATH%;%USER_PATH%;%PATH%"
goto :eof
