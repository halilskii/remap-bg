#!/usr/bin/env python3
"""
patch_bytes_gui.py - GUI zum Patchen eines bekannten Byte-Musters in
Binärdateien innerhalb eines begrenzten Offset-Bereichs. Erstellt automatisch
ein .bak-Backup vor dem Schreiben.

Erkennt automatisch, ob das System auf Deutsch oder Englisch (oder einer
anderen Sprache) eingestellt ist, und zeigt die Oberflaeche entsprechend an
(Deutsch bei deutschem System, ansonsten Englisch als Standard).

Als .exe packen (auf Windows):
    pip install pyinstaller
    pyinstaller --onefile --windowed --icon=HRT_MDG1_RSA_Patcher_icon.ico --name "Hibert_Performance_RSA_Patch" patch_bytes_gui.py
"""

import base64
import locale
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

DEFAULT_OLD = "91 10 00 26 F6 27 DA 0E"
DEFAULT_NEW = "91 10 00 26 82 02 DA 0E"
DEFAULT_MIN = "0x28000"
DEFAULT_MAX = "0x30000"


# ---------------------------------------------------------------------------
# Sprach-Erkennung / Language detection
# ---------------------------------------------------------------------------
def detect_language():
    """Ermittelt die Systemsprache. Gibt 'de' zurueck, wenn Deutsch erkannt
    wird, ansonsten 'en' (Englisch als Standard-/Fallback-Sprache)."""
    candidates = []
    try:
        # Bevorzugte Methode unter Windows/macOS/Linux
        lang_code, _ = locale.getlocale()
        if lang_code:
            candidates.append(lang_code)
    except Exception:
        pass
    try:
        lang_code, _ = locale.getdefaultlocale()
        if lang_code:
            candidates.append(lang_code)
    except Exception:
        pass
    try:
        import os
        for var in ("LC_ALL", "LC_MESSAGES", "LANG"):
            val = os.environ.get(var)
            if val:
                candidates.append(val)
    except Exception:
        pass

    for code in candidates:
        if code and code.lower().startswith("de"):
            return "de"
    return "en"


LANG = detect_language()

TEXTS = {
    "de": {
        "window_title": "HRT MDG1 RSA Patcher",
        "by_line": "Programm by HRT Performance",
        "files_frame": "Dateien",
        "choose_files": "Dateien auswählen...",
        "clear_list": "Liste leeren",
        "pattern_frame": "Muster & Bereich",
        "old_pattern": "Altes Muster (hex):",
        "new_pattern": "Neues Muster (hex):",
        "offset_from": "Offset von (hex):",
        "offset_to": "Offset bis (hex):",
        "backup_checkbox": "Sicherungskopie (.bak) erstellen",
        "patch_button": "Patchen",
        "log_frame": "Protokoll",
        "dialog_choose_files_title": "Binärdateien auswählen",
        "no_files_title": "Keine Dateien",
        "no_files_msg": "Bitte zuerst Dateien auswählen.",
        "field_old_pattern": "Altes Muster",
        "field_new_pattern": "Neues Muster",
        "field_offset_from": "Offset von",
        "field_offset_to": "Offset bis",
        "err_pattern_length": "Altes und neues Muster müssen gleich lang sein.",
        "err_offset_order": "'Offset bis' muss größer als 'Offset von' sein.",
        "invalid_input_title": "Ungültige Eingabe",
        "err_odd_hex": "'{field}' hat eine ungerade Anzahl Hex-Zeichen.",
        "err_invalid_hex": "'{field}' enthält ungültige Hex-Zeichen.",
        "err_invalid_offset": "'{field}' ist kein gültiger Hex-Offset (z.B. 0x28000).",
        "log_file_too_small": "[!] {path}: Datei kleiner als Suchbereich ({size} Bytes).",
        "log_pattern_not_found": "[!] {path}: Muster nicht gefunden im angegebenen Bereich.",
        "log_patched": "[OK] {path}: {count} Stelle(n) gepatcht bei {offsets}",
        "log_error": "[FEHLER] {path}: {error}",
        "hint_separator": "=" * 60,
        "hint_line1": "HINWEIS: Um die gepatchte Datei erfolgreich auf das MHD",
        "hint_line2": "zu flashen, muss in den Flash-Optionen unter 'FORCE CAL'",
        "hint_line3": "der Wert 'ATAT' eingetragen werden. Ohne diese Angabe",
        "hint_line4": "schlaegt der Flash-Vorgang moeglicherweise fehl.",
        "done_title": "Fertig",
        "done_msg_plain": "Vorgang abgeschlossen. Details im Protokoll.",
        "done_msg_with_hint": (
            "Vorgang abgeschlossen. Details im Protokoll.\n\n"
            "Wichtig beim Flashen von MHD:\n"
            "In den Flash-Optionen muss bei 'FORCE CAL' der Wert 'ATAT' "
            "eingetragen werden, damit der Flash-Vorgang erfolgreich ist."
        ),
    },
    "en": {
        "window_title": "HRT MDG1 RSA Patcher",
        "by_line": "Program by HRT Performance",
        "files_frame": "Files",
        "choose_files": "Choose files...",
        "clear_list": "Clear list",
        "pattern_frame": "Pattern & Range",
        "old_pattern": "Old pattern (hex):",
        "new_pattern": "New pattern (hex):",
        "offset_from": "Offset from (hex):",
        "offset_to": "Offset to (hex):",
        "backup_checkbox": "Create backup copy (.bak)",
        "patch_button": "Patch",
        "log_frame": "Log",
        "dialog_choose_files_title": "Select binary files",
        "no_files_title": "No files",
        "no_files_msg": "Please select files first.",
        "field_old_pattern": "Old pattern",
        "field_new_pattern": "New pattern",
        "field_offset_from": "Offset from",
        "field_offset_to": "Offset to",
        "err_pattern_length": "Old and new pattern must be the same length.",
        "err_offset_order": "'Offset to' must be greater than 'Offset from'.",
        "invalid_input_title": "Invalid input",
        "err_odd_hex": "'{field}' has an odd number of hex characters.",
        "err_invalid_hex": "'{field}' contains invalid hex characters.",
        "err_invalid_offset": "'{field}' is not a valid hex offset (e.g. 0x28000).",
        "log_file_too_small": "[!] {path}: file smaller than search range ({size} bytes).",
        "log_pattern_not_found": "[!] {path}: pattern not found in the given range.",
        "log_patched": "[OK] {path}: {count} location(s) patched at {offsets}",
        "log_error": "[ERROR] {path}: {error}",
        "hint_separator": "=" * 60,
        "hint_line1": "NOTE: To successfully flash the patched file to the MHD,",
        "hint_line2": "you must enter 'ATAT' under 'FORCE CAL' in the flash",
        "hint_line3": "options. Without this setting the flash process may",
        "hint_line4": "fail.",
        "done_title": "Done",
        "done_msg_plain": "Process completed. See log for details.",
        "done_msg_with_hint": (
            "Process completed. See log for details.\n\n"
            "Important when flashing the MHD:\n"
            "In the flash options, the value 'ATAT' must be entered under "
            "'FORCE CAL' for the flash process to succeed."
        ),
    },
}


def t(key, **kwargs):
    text = TEXTS.get(LANG, TEXTS["en"]).get(key, key)
    if kwargs:
        return text.format(**kwargs)
    return text


# HRT Performance Logo (PNG, base64-kodiert, damit keine separate Bilddatei
# noetig ist)
LOGO_B64 = "iVBORw0KGgoAAAANSUhEUgAAAQQAAABXCAYAAADiZTvnAAA0sElEQVR4nO1dd3hVVbb/ndtLQgggkC+QYUSRIiDdkofI5IlSJAJKHjyRQUZFBqUrPooIDI82Ag+kCKJRRxQpUUBHgUGkCUONgUBCCYRQAoHcm9vLfn+EtbPvybkloQW8v+87X3JP2X2vvdpeW1KpVAzl4C9/KwCqMM/DIVz6ckjXr7sV7Pp1IwjX5hVt04qmf68jfB8xFjgGJelmjslIxsit76Pf+yiIIoooBEQJQhRRRMEhKYsMEX4ssEyMMf735rJStwLh2LMbF1HkbUDtc6+govWrau1xM8oj/+ZOj/ubUaebxiHc6caIIooobhyaUA9VKlU5LsDv9/NnKpVK8dm9DEmSAuodReVQ1TiGyqCqcQiRINw8DSkyKH1Ik0HpmVqt5plWbVROZJAkCT6f71YVKooobgskSQpKvMpxCPSy3+/HY489hkaNGsHr9cJgMOD48ePYuXMn1Go1Hn/8cSQkJMDj8cBkMuHEiRPYs2dPgC7hXoFKpQJjDCqVCklJSejQoQP8fj9vVDm3BATWX06Vw60kjLEKy+RKaVTkeaSrHZWN6kvvyd+XLxjy9NVqdcA3ckIrT6+iv+VtqFQ++XPxHaX6h2qzcJyjUnnC9aG8DYPVmdKl9yltjUbD86U+Ky4uxq5du1BcXFyuDowxQKVSMfml0WiYJEnso48+Yowx5vf7GWOMrVy5kkmSxHQ6Hfvyyy8ZY4y5XC7GGGOffvop02g0TKvVMrVaXS7NqnVJTKVCiEsKeF+SJKbVahkA1rt3bxZFKWhcRFH1QX2Vk5PD6tWrxwDwuUqXSqViijoEdp2iOJ1O/tdgMMDlcoExxqk7u77yMcbgcDjg9Xqh0YRUS9ylkDj19fl88Hg8fDVQqVTw+XyKKzLdU3qmmMv1No1EFpWnGe6bisq34dKXr0YV5ViYbMVU0lexECt8OI5ADnkZw62+8neUnt9sLi1cHSNJR86xiXNUq9XC6/XyeimVT3H2iqyw2OE02b1eL39GHRHJoLhbIVZLrVZDpVIFNOq9SQSjuBeh1WpDijYBI1lOXbRabcBvcVWQWxvE1S3SFfHOQa40lCsZ5b8lSFJpI3q9XgBl9bbb7Vi8eDGys7NhNBrLycZyEAENx1HIO01MV4n4KsnsYnqk8I0UFdUJyH/L35fnL9aB9AdUZpFb0Gq1UKvVcDqdAXobeRtGwjHJOYSKcBR0T61W8zEglkeOinI4we6FQiQchvwdi8WCa9eucb2Y/PlNW9qqPhG4eRCJn1qtxooVK7B///47XawooogIpACNWGSIIjhE3QlR5NjYWKjVaphMJsTFxcHr9fJVhBAJwQy1osjLIP8dakWPJG8lmTxUGYLZsuWa72DpExfgdDphsVgAACaTCQDgdruRkJAAlUoFp9PJ0wtl8q2oDkVpdQzmcwOAy99WqxWSJMFgMECr1QZwNKHaWYljCOeLEa7fKuMt6vV6YbPZgr4bJQgVBDWkaIqkwRofH4+PPvoIDRo0gNPphFqt5u8HmyiRDAK5niZS5yhRZKiogkuefjgRgt4JJRLJ33W5XDh58iQOHTqEvXv3Ytu2bdyM3bBhQwwfPhyNGjUKECmCoaLOYkpmx2AghdycOXPw2WefAQCmTJmClJQUOBwOaLXagL6h+suVkuKqHIlofTMd/ahMWVlZGDVqFC5duqTYZhr5R2JB6ANxEhDkz34PXopAqbwr15eI8nHjxo2RlJQEn89XYbn994j27dsjLS0NFosFGzduxKJFi7Bt2zZs3boVRUVFmDZtGrp37x6x9eVWokaNGnC73VCr1UhKSkLTpk2rRLkqAq1WywmsElGK+uDeRDDG4Ha74ff74fP54PV6g5ok7zUwxlBSUgKbzQaXywW32w2Px8PFJ5/PF3DRfbpMJhPS0tKwatUqDB8+HHFxcTh8+DBGjBiBLVu23JFJ53a74XQ6Ybfb4ff7uRhIpni/3w+n0wm32w2v1wuPxxNWWXmnIFrFyFighKjIcJMhsvOSJOHKlSuw2Wxc3iTIrQAAAr6TP6+MvFjRckeSvlguMj/r9XoYDAbExcXxehIhlHs0BkufMQa73Y5atWph9uzZqFu3LiZPnozc3FxMnToVdevWhdls5rqbYEoxpXJS/nJPRLnVQZzwPp8PCQkJMJlM8Pv95fbtUBnUajU0Gg2KiopQVFQEvV4Pt9sNvV5fYV+RcCjfZoHPlZIX+8pgMOD8+fPlfD5ERAnCLYLf74dGo0F6ejrmzp3L3UiB0KZHQFnfcLMHV7A8g+Unfya3tFSvXh2NGzdG69atkZKSgjZt2gAoIxpyyO95PB5oNBrOPYwcORLnzp3DwoULcfDgQXTu3DnA36OiSrzSbwLzJ1MyvU/Exu/3w2QyYfny5XjyySfhcDjKpS+2l0qlwvbt2/HWW2/xe5HsebnZZkal50qLzpUrV6BWqxXFfA0g2lIDve+CeXN5vd6gyrCqyC6FR+TxDzQaDW9ouR5FHIS0gthsNpw7d+6WlLoq4cyZMzh8+DC+/vprJCYmIiUlBSNHjkSTJk3g8Xi44g1QHiPk1+H3+7nz19tvv40tW7bg6NGjt11HZTKZyvnliN6pch8KoLQN7gYE1235oxzCrQYREFGZcy9CnNDnzp3Dp59+im3btuHvf/87UlNTAxRZSisjiQDEcfh8PiQmJqJPnz6YPHmyoshVMYTe4VrKLZSWzefzQafTCc/CLxbkyStanm7+4lgxoli+3IELmBKiSsVbDNEEJdcL3EsXKQuB0hXIYDDg9OnTGDJkCLZt28YneajBKGfDGWP4z//8T8TFxQW03+26Kgq/388vquudvMTyiFeo+t1UgnA3mV8qipulELpX20jug+Dz+WA2m3HhwgUsWLAATqczrCKQ0hH1Ew888AA341blwDRivSpDTKoKVED51UquVZVTbnGDBFWeOlBpl5UcohNHOF/wUN8HS0/ucXajENMMp/BTkjfl393NAyYYxBVJHBNqtRrbt2/HqVOngiqy5KD29vv9iImJQb169Xh6t6r95HNA9DRVcsoiOVweMKgqE61IEFSHQGwP/Q+Ube5QmujNmzeH2WyGy+WC2Wzm9vhIPLKImEQCpYkVjqhUxgQnLzOZmMg8da+u9DcCkWj6fD7udmy1WlFUVFShtGgTkcfj4ffuRUJa1RBSqUidQVSvVq1a0Gq1sNvtyMvLAwDuj96hQwcMHDgQixcv5r7p9xKoLex2O4DICNLvGWRl8Xg8MJvNMJvN/H4k8Pl80Gg0sNvtOH/+PP82ShRuLUISBFEzDAANGzZEnTp1cOrUKWzfvh1//etfoVKpeGCUqVOnomXLlti4cSP33pKLH0pQCo6hBHEFEidkMLEi1HMR8udytpRYWK/XizZt2sDlcgVooaNQBrXbAw88gIYNG1Z4MkuShIKCAuTn5wfEoIji1kGRIJAfwrlz53gnkudWy5YtcerUKezcuRM7duzAn/70J+6majAY8Morr2DgwIFcrBA3+BAqu6LK5fhgG1SC6RHkOg76WxG5lAicqPiSl0tMn4jqrTNF3RkEc4phrNTsZjAYoFKp4Ha70a1bN8TGxgZ1UhLTEPUHAJCZmYlr165xK8XtQij9ljw2Bf2l/o1UV1Jx3Gr9hCp0xKRDhw7BZrNBr9fzCf9f//Vf2LRpEywWCyZPnozExEQ0btwYNpsNklS6gw0o780mToTKNlYogiCXX5VYeqVOrugEpZVKSYn2ewbpl4Ay+d/lcqFPnz4YMmQI1yeF0vfInX2cTidWrVoFr9cb5chuExQJApl4fvvtNxw/fhytWrXiCp6uXbvijTfewMyZM7F9+3YMHToUY8eOxWOPPcblxNuFYB5Xt3uX4c0OoRZq4lQVyLkhcsAiN1+1Wo2ePXtizpw5nDsItalGhNfrhV6vx6effoqtW7fCYDDc005dVQmKYdiB0g49f/48Fi9ejKVLl/KVUa/XY9y4cSgqKsLKlSuxZcsW7NmzBykpKUhOTkbNmjURGxvLlUqiq688DxFyM14wvYD8fZHbIEsA3ZebUEOx9vJ8Qk1IOddz9erVoGlVBnfj4Pd6vVCr1WjQoAGeeuopPPvss3j22WdhMpm4ziUSiw+NsV27dmHSpEnc7TmqP7g9UIypSJNIq9Vi1apV6N27N7p06QKn0wmv1wuj0YiFCxeiY8eO+PDDD7F7926sW7cO69atK5cWEFpJKMqLVQlKfg4E0Zwq+mSI4kNF6iTujdBqtejSpQsaNmwIm80W0Bf0PylxSWQBbpxLkXsRyssvJ1LEFeh0Omg0GlSrVg3NmjVD27ZtkZSUFECYjUajouJW9JpTq9VwuVwwGo3IzMzEO++8g7y8PBgMBng8njsilsmV0krxQO41KI4i6kxiAceOHYu4uDg8+uijnCWUJAkvvfQSUlJSsGbNGmzYsAEHDx5EcXEx3G53RDoDkRupCMKt3hV5X+nbcFYHoLROtGHnRgcrfU+T/NKlS+jatSuef/551KpVi+d3twxC6v9QocVoVyMRA5VKBaPRiPXr12Ps2LHIzs6GTqcL8EOI4tYjqMggSRKaNGmCs2fPIisrC6+++ioWLFiAjh07cn2C0+lEzZo1MXToULz88svIy8vDxYsXeUAJMc1gk7Iy3oXhJnhlrRpyy0OoNMVzGt5//30cOnSo0sSBWGmPxwNJkvDvf/8be/fuxbx58/DKK68gLS0NCQkJ8Pv9KCkpgV6v55pukau7EciJYbi6yIkTRZIisU3+XC4SkhKSlIVFRUX48MMPMWfOHJSUlMBgMJRzbqvqepV7AeUIAlF2r9eLtLQ05OXlYfHixTh+/Dj69++PESNGYODAgahRowYAwOVyweFwQJIkNGvWDM2aNbvtlbiT8Pv9WLBgwQ2lQROJ/pek0p1zWVlZGDlyJFatWoX+/fvjhRdeQO3ateFyubjMTjqaypRbnPRy4iIP1iI3r5GIoWSCEz1bgUDTrqjnAYD8/HysWrUKq1evxp49e3gcCRKHlPQ+Udw6KMZUBEo7NS4uDrNmzYLL5cLKlSuRn5+PsWPH4ttvv8WAAQOQnJyM+++/H3q9nn8jt+uLrGOkuNnyYjBTYygTmBLEABqkP6CwWfSdfDJECvE7n88Ht9vNtfK7du3C7t27sXLlSrz00ktITU1F7dq1eWgy8q2Xl1ucrGKgUiIkcrhcLk6clPpN1PdQ2h6PBz6fL8CCIJZFScyh2An/+te/8P333yM7O5u3JwDOKQW2YejtyxWJaREp5MRIKRah+JfKfDeboRV1CCI7HBMTg/nz56N58+b44IMPcPHiRfzyyy/YuXMnHnjgASQnJ6NLly5o0KAB6tatC5PJxGVruQNPpLidBEGpA4PpIWjy6fV6PgmJVb5ZEMtGBIgmyvbt27Fz50589tlnGDhwIFJTU1GjRg0wxrg8TpNZXIXFfSm5ublYvXo1zp49C6PRCEmSYDab0a1bNzz++OMAwOspTgg6vs7hcKCkpATVqlWDJElcfCEiKSpI7XY7Ll++jOLiYly5cgVHjx7Fnj17sH//fuTm5vK9DrSgiIF37uZJdTcjpGqaOlqj0WDEiBFgjOHtt9/mE+Lo0aM4evQoPvroI9StWxe1atXi8epJRqzqrJ6SB6G8zDT5vV4vUlJSMGHChNvikCR3rqI4fdu3b8fevXuxYsUKvPzyy+jevTsSEhL4Dj2luANarRYOhwP169fHU089hfT0dKSnp+PatWsAgPT0dKSmpmLQoEF45JFHoFarORGgCe7z+eBwOJCRkYHVq1fDbrcjNjaW+wmIZXW73bBarbhy5QqKi4t5AFaCTqfjDm9R566qg5CuyyRLejwe6PV6JCYmct+Cbt26wW6347fffkNhYSGKiopw4cKF213+246aNWve1vzESUYOO0Sod+zYgR07diA5ORlpaWno1asXEhISoNFouKZf5II0Gg1UKhWSk5ORnJyMv/zlL/jss8/w3Xff4fTp01iwYAHWrVuHXr16YeDAgWjVqhWAssAfdPZE3759kZSUhCVLlmDTpk18w1coaLVaaDSaAHMkLRpRYlB1EFJkoJVSPIjC5/PB5XLhhRdeQM+ePZGbm4uioiJ88sknWL58OVcIVVbTX1VBilbyOxDla1FeDqV/qMzAl+dBbDaJEsQx7Ny5E+np6Rg8eDB69eqFmjVr8hDnot7A4/HA4XBAo9GgXbt2aNeuHV599VV8/PHHWL16Nc6cOYP58+dj7dq1SEtLw+DBg9GoUSPumEaBT7p27YquXbvi0KFDWLJkCTIyMlBQUMB9JkSfftGV3O128zrRNvKqIHeXlkn5IJxIxrKoP7tbzMNKqJA3CzUU+amr1Wo8+OCDUKlU2L17Nyck9yoLWJXOWBAVmHQg6t69e7F3714sX74caWlp6N27N+rXr89FCXJoAsBZdZ/Ph4cffhgzZ87EgAED8Pnnn2PlypU4e/YsZs2ahYyMDKSmpqJ///5o0aIFgFI/A5vNBo1Gg5YtW2LevHkYNGgQPv/8c6xZswZnz54NUE7SMWhyXZKc2EVx51EpUiZSdYfDUU7LHe3gWw/RmkMTW6/XQ6VS4ddff8Xo0aPRp08fLFy4EJcvX+bigsvlCjhVSqPRcK7jkUcewezZs/HVV19hyJAhqF+/Po4fP46ZM2fi+eefx+TJk3HixAnodDqYzWZIkoSSkhL4fD60bdsWc+fORUZGBoYNG4Y//OEP3LOVlIZRVH1UmCCIcilR+IqaFaO4WSi/hZsOndVoNNizZw/++te/olevXpg7dy4uXLgAk8kUsCsRKHN7djqd8Hg8eOKJJzB//nx88803eO2111CrVi2cPHkS7733Hp5++mlMmDABR44cgU6nQ0xMDPx+P+x2O+x2O1q1aoX58+fj66+/xoABA1C9enVcu3aNKyjlvglRVC0oEgS5/TWY2Q4oP6hEc9W9DCV9gZJ5VYyteGPedv6AS5LILl/62+/3wuNxwefzwOVywONxQaNRQa2WsGvXLowYMQI9evTArFmzcP78eR4WnpyMgFLNP8UwcLvdaN++PRYuXIiMjAy89tprSExMxMmTJzF16lT06NEDY8aMQU5ODkwmEz+52Wazwe12o02bNli2bBnWrl2LP//5z7jvvvu4zwLtfyArVGQLioTS4Rrsuvnfy0UaMv/K40aKf+923L3ajygUIa68NHA1GhV0Oh0OHTqEsWPHIjU1FdOnT0d+fj70ej0/T4DEP0mSuOuw1+vF448/jvnz5+O7777D6NGjkZSUhJMnT2L27Nl47rnn8P777+P48eMwmUx8C7zT6YQkSejYsSMWL16M1atXY/DgwahZsyYXUTQaTVAldBR3BlGC8DsAY6XKx5iYWOh0Ouzbtw8TJ05Enz59MG/ePFy6dAlarRY6nY6bGMk1WqvVcg/G5s2bY+bMmcjIyMCYMWPQoEEDZGdnY9KkSejWrRsmTpyInJwc6HQ6vsPR4XDA4/EgOTkZCxcuxMqVK5GWlobY2Fg4nU6u+/g9cJV3A6IE4XcAxkqtCna7LYBlP3jwIIYPH46uXbti/vz5sFgs0Ov1PHYBWSeItadNbY888ggnDMOHD0diYiJyc3MxZcoUPP300xg/fjxycnI4kSGnKMYYUlJSkJ6ejm+++QZpaWlQq9X8WVQXdedRIYIgykvBfPZ/T6yf6NdPUPJyJERyUMmtAlmFSGdAh6tqtVocPHgQo0ePRmpqKpYsWYKLFy9Cr9cH6BmAUh0D+aL4fD60aNECc+bMwTfffIM///nPqFu3Lk6fPo1p06bhueeew+jRo7ny0WQygbHSE549Hg86deqEJUuWYO3atejduzdiYmJ4UF4SY0iUuRUihaiIVbrEs03lZzCIp1Tda4hyCL9DyAk77ZjcuXMnXn/9dfTs2RNLly5FcXFxgCKNPFfJxEyOT48++igWLVqEjIwMvPHGG0hMTMSxY8cwZ84cPP/885g4cSKOHDkCg8HAj1cvKSmB0WjEs88+iy+++AJffPEF+vbti2rVqsHhcMDtdnOiIHcUiuLWIdrKv1PI/RjIC1On02HPnj0YNmwYunfvjk8++QQlJSXQarXcHVoeqcnlckGj0XCrxMaNGzF27FjUq1cPJ06cwJQpU9CzZ09MnjwZJ0+eRExMDEwmEz/MRaVSoXv37khPT0dGRgb69++PmJgY2O12MMb4Jqwobj2iBCGKAEczilykUqmwc+dODBkyBC+++CJWrlzJ97EQiJDQ6u1wOOD1etGiRQtMnToVa9euDdAxkB/Du+++i9zcXBgMBuh0Oi7CMMbw5JNPYtmyZcjIyMB///d/w2g0wm63cyVnlDDcWqgCbbGlCOa7Lfrwy8+0u7sCWZTZ7yO5Sm3+pRDjCpB/v7hdPJhd+sbl4FA29Eiu4CBOgZSGLpeLx2PweDzYtGkTBg0ahLS0NKxfvx5Op5NHOhI5BoPBAACcSLRt2xYffPAB1q5dizfeeINzDNOnT0dqaiqmTZuG/Px8foaDJEmw2+1Qq9Xo3Lkzli5dim+//RZ9+/ZFjRo1uLs1ESyS7Svj3yE61yl9K96X96n4TO6cV3nRpmJjsnJXeEQ5hCgCIBItInAajQZerxcZGRno06cPBgwYgG+//ZYrAJWUcH6/Hy6XCx6PB+3atcP8+fOxevVqvPbaa6hTpw6ys7Mxfvx49OjRAzNmzMDZs2eh0+lgMBjgdDrhdDqh1WrRqVMnpKenY/Xq1RgwYADi4+MDgs+KRCGKG0eUIEQRFuSspNfr4fV6sWbNGvTv3x+9e/fGunXruCMTbWASvVXVajVsNhu8Xi/at2+PDz/8EOvXr8dbb72FxMREHD58GO+88w66d++OCRMmIC8vD7GxsQDAd9b6/X506tQJy5Ytw8aNGzF48GDEx8fD5XKBMQaz2RxVOt4khGxFkR0UWWMgcI/878nTTFwNxVVRfC62173SLiQqkbOSw+HAxo0b0b9/f/Tt2xfr16/nkaiBMjaeNr75/X7YbDZ4PB60bdsWs2fPxtq1azFo0CDUqVMHWVlZmDp1Kp555hnMnDkTBQUF3PQJgIsxHTp0wMKFC7F69WoMHDgQZrMZJSUl3GfiZkevUhr/Sver4lEClYEKKC9PkeKIoueSjGc0GrntmnbWxcTE8D3woq37XoLfX1Yn8sGngB8kz9Izk8kElUrF/4qxEoDKybtVBRTDkeIYkBdjRkYGXnzxRfTt2xcbNmzg+gdygDIYDDAajTCbzXznI8VjWL58OdasWYOBAwfij3/8I/Ly8vD222+jZ8+e3FnKYDBAr9dzt2idTocnn3wSK1aswI8//ogBAwagTp06MBgMfFfnjULsSxr/4r4d4kqo/0mnolarb/vJYTcTimHYidr99ttvPCKOwWDAnj17eCix7du3czbRbDYjMzMTwL0py4lKpEuXLuGf//wnN7UxxnD58mX+7qZNm1CnTh14PB7ExsYiJycHQNmZC3cz1yCWWyT8ZJL87rvvsGnTJvzpT39Camoq6tWrF0AARQU0fU8T+KWXXkKDBg3w0Ucf4eLFizhy5AjeeustTiwSExM5F0Bp+Xw+mEwm9OnTBwkJCVi2bBmuXr0KvV5f7myQioIiUl25cgUOhwN6vR6ZmZlcebh3717OKZnNZhw9epQ7ct3N4oukUqlYMC0rWRXEQKLkqUZRcUi7rFKpYLVaAdwNRCFcBN9AlNa9LNgHEQLGGPR6PQ+LLkkSTCYTnE5ngMKNtv6KEZrvNRDXRJYKiiwlJyIiREJB4kFJSQkkSQVJAo/fIEkqaLWagLYTlZ3kCWmxWPhkvJG2pn6uVq0aSkpKOFEjt286PIasTKRfIRfsyu2ArNiYrBzCEypFgkCx7og9pNWN2CaKliSaHsVoSlUfFW98SVJzcYrMbrRVmAYJ1Z/YR5fLFeDZR9zBnXRhvlWgxUMMWis/dUkcZxS7QWwTUQdB402U1+XjlLhVoFSMIHOn6Fp/I/WhhVA8+4LyIA5F3NYuj8J91xKEoA+DyLoiG3h7BvaNNla4mP0Vi/lPLG+4WIAia3zn9QbhJsiNs7nimJBP/lBjqfTbwPDzjAGSJI7B8n0oire3Ii5jqPqIz0Xc2vlwo9zlDRKEqoOqRRDuTtx6gnBjCFe+e6EPbhS3niDc6VEQRRRRVCFECUIUUUTBUaEw7FFEca8iEtn/zuuBbj2iHEIUUUTBESUIUUQRBcdNIQjBtpDefNz8U5aBm+//fqOmp9thzrpb3SCUfGbuRlTVcivqEMTBp3QYp9LgJCcl8tgLliY5o1C6kQx0xqgcUHQ4ET3G5LZppRiH5EQlflNaDvFdBr+f8X0aFO8vmFORfK8CBSVVOjJezFPpfbFO1Ga0qYq+V26nssNaqKxlzmOB74p79yP1rlOKESB3S6ZnVH7RUYmCt4rHzZelE4GNXAjiQqBTqivq6yHvg3CQB4BVGofyRUYc86Hykfcv5SdvY8Yi2w8j5iP2cSQIevozFSSSoA/yTgoF0fOLPP3kREfJxVWSVGCsLK6fPH+aCPKJJ3+PNp/QN8rBYqXrnmdlO9vEtOWERuw4Gjji0exK7UUTQvSCo46mNERPPDFfJa89+fsGg4FvDy5NU13ufXKnpt+hBg2581J76fV6XjfxoFOCGEgGQIBna2Vce8UxQn0hhouvqHcipUVbusnzMBj8fj90Oh1v43B5iWOC+obuU3vRfXH+UDsqzQEa++JGRBFKruKUdqTnkio6JskHS0WgxFGIg438zyvqWkobR4DyFFJcYSsCkfDJG5IaXk65I4UYulyJgNEEcbvdEaVHfaK0eYbagyYsY6zCbUF7U5Qmq9je8n4jgibnEMTBq1arA+qpdLJyuNVd5ECD5R8pgaH6yCNihyKKYttQX4TjnGkMVHQeUZ2UOMLKzsuIF2wlgkADr3379ujYsSNfxQnyihcXF+P06dP47bffcOnSpXKZi66+ANC2bVu0b9+eHzpKz0WfdeowjUaDU6dOYdOmTfB4POXYPPpdr149pKSkwGQylVu9RRbWarXi0qVLyMzMxLlz5wI2KsnLTPm3bdsWrVu3BmMs4Mg6EWJ0odOnT+OHH37gk1e+otNg8vl8SEpKQvv27dG0aVM0atQIer2er1aFhYU4fvw4jh49isOHD/NDW8XBItaT+iguLg5dunRB3bp1A0QIEX6/H263G+fPn0dWVhZycnK4iCGfXFQvCr3euXNnAIDdbseaNWtQWFjI25Hep7ajvS8pKSlo2bIljEYjcnJysGrVqoD3wxEEnU4Ht9uNhx56CB07dkR8fDwKCgrw9ddf88As8jGhBGq7hIQE9O3bF2azGUeOHMHatWsBlC08YhqMMcTGxuK5555DgwYNsHHjRhw4cCDk5i2aQwDQsmVLtG7dGvXq1UNCQgLq1KkDvV4Pq9WKkpISWCwWFBQU4MSJE9i+fTuuXLmiyOkSIWrXrh1atWpVToQV+42xsk1158+fx+bNm/nempCEU6VSMfmlVqsZADZkyBBGsFgszOl0spKSEuZ0OpndbmcOh4O53W7GGGMOh4Nt3ryZJScnM0mSmF6vZ2q1mkmSxNPUaDQMAJs8eTJjjDGv18uuXLnC7HY7s9vtrKSkhFmtVma1WpnFYmElJSXM4/Gwf/zjH0yj0fD01Go1v7RaLQPAHnvsMWa1WhljjDmdTmaxWHi6DoeD2Ww2ZrfbmdPpZG63mx0+fJi99NJLTKfTMa1Wy9OjsqpUKl7ed999l5e3qKiIWa1WZrfbmc1mYyUlJaykpIRZLBZWWFjIXC4X+/LLL8u1pyRJPC+dTsfq1q3L3nvvPXbixAme9oULF1hOTg7Lzc1lBQUF7OrVq4wxxtxuN9uyZQvr0aMH02q1TK/XM71eH5C22BZJSUns7NmzjDHGiouL2eXLl5nFYmFWq5WXt7i4mNntdub1elleXh4bOXIkMxqNTK/XM41GU25MUNrDhg1jIv72t78xrVbLTCZTuW/1ej0DwFJSUtilS5f4N1u3bmUGgyGgrZXy0+l0TKPRMJ1Ox4xGIzMajeyLL77g6dhsNjZw4ED+nkqlCvhf6aI+ffTRR5nT6WSMMWa1WtmMGTNYjRo1eLl1Oh2/VCoVS0hIYFlZWYwxxsaMGcMABM1Hp9MxSZJYw4YN2cKFC9n58+cZY4y5XC52+fJllpuby44cOcJOnjzJCgoKWFFREXM6nczhcLDk5GTFtGl8AmDz5s3jY8ZisTCbzcbcbjfzeDwBl8vlYowx9sMPPzCz2cwABG1v3j6hqDLtKc/NzcWoUaNw/vz5AHaLKNaDDz6I8ePHo3Pnzrh27Rr27dvHqaycOwDAZdsdO3Zg+PDhnF0jCkecAgVkKSoq4lQ3GHXzeDxwOp0wGAwYMWIEduzYAaPRyFduKkedOnXwl7/8BampqXj//fexf/9+ZGVlBcjHcspM7UAnHdnt9gClH5WZsdJwXlevXuUBSgHwtiBdhEqlwqhRozB69GhYLBbMnj0bGzZsQH5+PiwWCyRJgtlshtlsRosWLTBo0CB07twZ999/P/r164ddu3bxgKYixNWBjkn74IMP8NVXX8FgMJRTomo0GvTo0QOjR4/GhAkTcPDgQfz888/Q6XRwuVyK7Uz1pK3GI0eOxPHjx/HJJ5/w7d6MMa5jaNasGebPn4/Y2FicPn0aSUlJQdOWQzxOzmazYfTo0UhLS0N2djY2bNiAYcOG4X//93+Rk5ODHTt2cAWj2HfB4PP5YLVa4ff74XQ6MXbsWDzxxBOYMGECtm7dyiNMi7sxKZxbMJZd1B/Fx8dj+vTpeOGFF3D16lWMGzcOmzdvhsVigdVqhd1u50fe6fV6xMXF4aGHHsKpU6fKKTAJdI+UqAcPHsSYMWNgs9kCdDTi/IyLi0NhYSEPdx9WrArFIQwePJgxxlhOTg6Lj4+nHUCK1+LFi5nX62WZmZmsTp06TK1WM51OF7DqEnX+n//5H8YYY+vXrw+ZpnjRiiinmLRytW7dml25coV5vV5OZYNdTz/9NOcennnmGQaAcwniqkVpjxo1ijHG2K5du5jJZIqovGJ6xCXRatO2bVt28eJF5vP52JQpUwK+uy7CBVxNmjRhBw4cYIwxtnz5cqZWq8txCGK/JSYmsmPHjjHGGHv11VdDlrN+/fosOzubMcbY66+/ztOWryTUFm+88QZjjLHMzEz297//ndlsNpaXl8datWrFAHAuSK/Xs9jYWLZmzRrGGGMrVqxg6enpjDHGNm7cyNsi2IpFfRsTE8MAsO7du3Ou7+WXX2Z6vZ4tWrSIMcbYli1bWN26dfmYA8DbJBiH0KpVK1ZYWMhsNhsbPXo0+/zzzxljjBUWFrLRo0ezWrVqMQDMYDAwSZJYQkIC279/P2OMseHDhyuu4sTNAGB9+vRhNpuNOZ1ONmTIkHJjQ6mfqf/1en258ovzZ/bs2Ywxxv71r3/x/CIZj6E4g4g4BILBYEBiYmKAnHqdmECtVqNx48Zo3bo11Go18vPzUVJSEiBTykGUrkmTJvj44495WC2RO6BITD/99BPS09MDtOhKChIK4ebz+VCvXj3UqFGDH15KAV0AoEaNGnj++edhNBpRUFCA8+fPh60/5ZeYmIh58+Zx0yqthlRPnU6Hb775Bj/++COAsj39JE+Scu0Pf/gD4uPj4Xa7sWPHDh5yjTgR0dKgUqlw9OhRHDhwAC1btsRDDz2E2NjY64FEgm8xpjLHxcWhevXqXNkr6myqV6+OF198EfXr14fdbkdBQUHAHv9QMBgMmD9/PpxOJ8aNG4fx48djyJAhXJ/g9/sxYcIEpKamYteuXZgwYQLGjRsHABFpvCloitPpxIMPPoiZM2ciNjYWs2bNwpdffgmv14vp06ejefPmeOqppzB+/HgMGzaMB2aJBBTw5Ndff8XChQuRl5eHkSNHYtasWejYsSOmTp2KPXv28KA4oSBXUj744IMwmUw4deoUNm/eDEmSONfk8/kC0hM5WHZdtxSqD6ifGzRogMWLF3N9jVyxq9PpsHXrVqSnpwdYNkJBQx+LoAalyR8bG4vVq1eXM0HS79q1a8NkMmHXrl2YNWsWV2ZQx1NBROUIANStWxcdOnQIyJPg8/lgNBpx5MgR/r08+ISS8lCr1WL27Nk8jLfP54Pb7YbT6eSTICkpCcXFxZgzZw6ys7O5Ik+usJT/NRqNaN68OYxGY4Cpjcqi0Wjw008/8Rh7ZG8XiQKAAL8GamOPxxMQyJTS12q10Gq1sNvtAVYLKpOosBTbhv6++eabeO211zixpWAuJPY0btwYarUac+fOxZYtW7iYJUIcH5QHBYiZM2cOkpOT0atXL5w8eRLvvvsuPB4P+vXrh6FDh8JqteK9995Dfn4+YmJiSgfddcWoOBHk6auuW2CqV6+OmTNnonHjxli3bh2mTZsGt9sNlUqFM2fOYMqUKVi0aBEGDhyIrKwsLFq0CHq9XjE4i9i3arUaZrMZkiTBaDTC4XBg0qRJyMzMxMSJE9GjRw888sgjmDZtGpYuXcrbn9pcDqU5RPdE4k5loYWPFlUSQUlMEhWEwSZxrVq10KFDB07oxTlBkczy8vL4mAlHDIAwm5uoQE6nEwcPHuQTnSpJ1K6goIDLn4WFhXzABwMNuKysLPTt2xcOh6NcvlRJOuNPafAoldfn8yE7Oxt5eXkBNuaGDRsiOTkZjDF8//33mDFjBvbu3VuurqFw7NgxDBgwAJcvX+adRoNDnGxy/wEqO63OFy5cQHFxMWrWrImHHnoIGzZs4A5MNFkkSeK+BHFxcWjSpAkAwGKxwOFwhG0LmhCnT59Gbm4uTCYTL0t8fDyefPJJ6HQ6/Pzzz/i///s/bN68OSDdcOn7fD4YDAacPHkSo0aNwtq1azF06FAcOHAAWVlZmDJlCkwmEyZMmIAff/yRE9FQEIkBmevefPNNpKamAgAeeOABfPLJJ4iNjeWrosfjQfXq1WE2mzFlyhRkZ2dj586d3LwdCWih0ev1WLlyJY4fP45Ro0ahX79+WLx4MZo1a4bFixfDZrMBAP8rgvQMND9OnDgBv9+POnXqoGHDhsjOzg4YLyJRpHErOrKFah/ql5ycHAwYMACFhYUBz8Xy0MIYLOqUHGEJgs/nw8WLFzFkyBCu3AtWWKK2cjOQEvx+PywWC06dOhWygLTyikd5hRpYPp8PM2bMwE8//RRwPzY2FjNnzsTgwYPRoEEDxMfHc0WL2DnB2oEa9NKlSygpKSnXcZJUeuqQ6C9B98U0JEnCoUOHkJ2djU6dOqFfv37497//jd27d/PDUwkulwsxMTF488038R//8R/w+/38gBRRgRaszIwxfPzxx1ixYkXAM71ej2HDhuFvf/sb7r//fqjVahQXF3OlIKC8Csrbglju/fv3Y8aMGZg7dy7GjRuHq1ev4v7778dXX32FuXPnBhBPcVKIELkcIga9e/fG8OHDYbVa8fPPP8Nms0Gv16O4uDggbN3mzZu5+Xbq1Kno27cv8vPzFX1iRFBZqK1UqtIoygcPHsQrr7yCHTt2YNKkSRg2bBhatWqFhISEAK5OqQ5ETHfv3o1jx46hadOmeOedd2CxWLBv3z44nU7Fb00mE/74xz+isLCQH0QTjDBQH1itVuTm5gZNk2AwGLjJPhxCEgStVgu1Wo0aNWqgVq1auHr1aoAjCLFBohNKJBpkCmHdunVrfPnll4ouwcQyGo1GHDp0iIsiwSql0Wig0+mg1+v54aAkCtBhIW+//TZ8Ph+GDh2Kr7/+GuPHj8fChQu5TiDYJKCQ86T5p+PGgPKiC6UhdyBirNRZSK/X4+rVq5g8eTKqVauGNm3a4Ntvv8Xu3buRlZWF4uJiuN1u6PV63HfffWjfvj3atWsHm82GpUuXYu3atWG5GeIuqMySJPGYgzqdDk6nE/PmzYPZbMakSZPwj3/8A/Hx8Vi+fDnXuwTjEkhGp/DjjDEYDAYsW7YMrVu3xsCBAwEAu3btwtixY+FwOHje1I5GozFouVWq0riUDz/8MGbPno3Y2FgsWbIEY8aMgdVqDbDuAGX+CU2bNsXKlSvx+OOPY8aMGXj11VfLcZ7yvIxGIxfJgFKuioiM2+3Ghx9+iH379mH69Ol46qmnAvKkNMT0aE6o1Wrk5eXh3Xffxfvvv4/k5GR8//33yMzMxLFjx3DlyhVYrVYYDAbUrl0bNWrUQP369XHfffchLS0NO3fu5Nytkj8CtePDDz+MFStWcG5JzhGRpe7gwYOYM2dORJYGjbxi4gA/ffo0fvnlF1y4cCGgcOLEJCommveCgSbI2bNnsWfPHkiShKZNm5bz9SZqzRgLiKZL90SdBN23Wq348ccfERcXh/z8fD6YxU62Wq2YNGkSPB4PnnjiCXTp0gVZWVn45z//GeBnT2Ug1v/cuXPYt28fDhw4wAme2KhK/8t1IlQekn+3bt2K3r17o2fPnnjyySfRqFEjtGjRgotHXq8X165dw6lTpzB9+nT88ssv2LZtW8CBJHIWkr51uVzYvXs3CgoKcPbs2YCVi0Qaj8eD6dOnw+v1okuXLnjmmWdw8uRJbNmyhSu85DoSADhz5gx2796NU6dOwel08iC8brcbc+fORUxMDLRaLRYsWIAzZ85w8ZExhszMTPz666/Yv39/ufHGWJnzk1arRfv27XH69Gns3r0bc+fOhdVq5ayvuEJT/keOHMHEiRPx+uuvo3bt2mjbti1+/vnnADOriOLiYvzwww+Ij4/nnK948hQR019//RX9+vXDmDFj0KZNG/j9fpw+fbpcvyv1f0ZGBo4ePYpu3bohOTkZ9erVQ6dOnVCtWjWuD7Jarbh69SouXryIzZs34+LFi0Fd+WlMnjx5Env37oXH40GTJk0CtgIQRB0UiQ2hCCQfp6ognoqUuU6ng1ar5SHW5Rt1IoFcvlKr1TCZTHzgK1VcnOwajQZ2u51TOCoDPff7fVCp1JxykoKO2C4a1KI1g94l7kEkBHSRYpDsxV6vFzabLYCbiET3oATyU6ABXq1aNcTFxfHBS8eYFRUV8TYS9QvUF6JvAaUrikF04pFIdMW6kfLJbDbD5/Ph2rVrAeIQvU9abJPJxFd8h8PBy0/Hwouh58lLkdqZ9gJ4PB6urxBB6RK3Rz4CogtwMKUyKZ3psBYAKCkpAYByXAVNlJiYGPj9fn66tPw5jVsKK096EDoQNxjExUp02TabzahWrRp0Oh0fQ+Q/Y7Va4fV6OcdCvjoiiAsn7ozaVsxPhKi7slgsEW0XCLqXgS6RIt9oiHUqNFFhUXaTa/Tl35Rp6SUwMEhAAJERiYvoXiwXQ2hwikfQla6sgN/vC9DIkv7C6XTyhqVVivKqDEEQFbPU+UoKJXGS0/uiDE7vlqYnwe/3XZ9IDF6vh2/k8vn8AMo4MCIiYrpiyH0x7bJvGNTqMtdmkUWldhUJFbH+VFZqP0pTrmOi56L2XRwr8lVeqd3LFogyXQURE6WFTNTOKyncKD2qi2j2Lk2fQWltpLrQ+6JVQanelBe1DylLg+miqA/leYYai+H0KTwdJYJAGVDFRE1ouIxDZia0HjWq3Bwk5i3+Fm3/kiQBjEF1vbMprXCNVUY8/FCrNVCppOuTpUxRI7J8lBedLiRusw1GwCIBlUUcYOLAFAcnpU+/xYlI9RTLWuqHInH2W06ARRAhoJU5WFkpf5pY8v0nVCZqK/meE/qfBjylo9RH9L9YbqqLUrkIlLaou6EyhdI7iWKiHDSRqSzUT263+zohUE43MD9W7j1xwaX8RV8VpfYRyyP3OQhWBip3RTbnhQ3DfiMEIHKQQ1UFQGNfvCWVrpTly1uaPmMQOlL8HUlmoc4ZqET5y0GlkK5QgrD9EHyAlNYzMmed4GUQ66jQ+Dc5+JacEIZv47I+CqfLCpJjmPRvBJLsb2Xzr3wbRzqPw3oq3npiUAkEaddwZS0bI0z2u4LZV/bDG0j3RvqhIsUNXgYW5P9bgxtp41vVP5VHeS7htpcgwvETjakYRRRRcEQJQhRRRMHx/xk13PNAyAKbAAAAAElFTkSuQmCC"


def parse_hex_bytes(s, field_name):
    s = s.strip().replace(" ", "")
    if len(s) % 2 != 0:
        raise ValueError(t("err_odd_hex", field=field_name))
    try:
        return bytes.fromhex(s)
    except ValueError:
        raise ValueError(t("err_invalid_hex", field=field_name))


def parse_offset(s, field_name):
    s = s.strip()
    try:
        return int(s, 16) if s.lower().startswith("0x") else int(s, 16)
    except ValueError:
        raise ValueError(t("err_invalid_offset", field=field_name))


class PatchApp:
    def __init__(self, root):
        self.root = root
        root.title(t("window_title"))
        root.geometry("640x700")
        root.minsize(640, 600)
        root.resizable(False, True)
        self.file_paths = []

        pad = {"padx": 10, "pady": 6}

        # Logo laden (aus Base64, damit keine externe Bilddatei noetig ist)
        self.logo_image = None
        try:
            logo_data = base64.b64decode(LOGO_B64)
            self.logo_image = tk.PhotoImage(data=logo_data)
            root.iconphoto(True, self.logo_image)
        except Exception:
            self.logo_image = None

        if self.logo_image is not None:
            logo_frame = ttk.Frame(root)
            logo_frame.pack(pady=(12, 0))
            ttk.Label(logo_frame, image=self.logo_image).pack()

        ttk.Label(
            root,
            text=t("by_line"),
            font=("Segoe UI", 8),
            foreground="#888888",
        ).pack(pady=(2, 0))

        frame_files = ttk.LabelFrame(root, text=t("files_frame"))
        frame_files.pack(fill="x", **pad)
        btn_row = ttk.Frame(frame_files)
        btn_row.pack(fill="x", padx=8, pady=6)
        ttk.Button(btn_row, text=t("choose_files"), command=self.choose_files).pack(side="left")
        ttk.Button(btn_row, text=t("clear_list"), command=self.clear_files).pack(side="left", padx=8)
        self.file_listbox = tk.Listbox(frame_files, height=5)
        self.file_listbox.pack(fill="x", padx=8, pady=(0, 8))

        frame_values = ttk.LabelFrame(root, text=t("pattern_frame"))
        frame_values.pack(fill="x", **pad)

        self.old_var = tk.StringVar(value=DEFAULT_OLD)
        self.new_var = tk.StringVar(value=DEFAULT_NEW)
        self.min_var = tk.StringVar(value=DEFAULT_MIN)
        self.max_var = tk.StringVar(value=DEFAULT_MAX)

        ttk.Label(frame_values, text=t("old_pattern")).grid(row=0, column=0, sticky="w", padx=8, pady=6)
        ttk.Entry(frame_values, textvariable=self.old_var, width=40).grid(row=0, column=1, padx=8, pady=6)

        ttk.Label(frame_values, text=t("new_pattern")).grid(row=1, column=0, sticky="w", padx=8, pady=6)
        ttk.Entry(frame_values, textvariable=self.new_var, width=40).grid(row=1, column=1, padx=8, pady=6)

        ttk.Label(frame_values, text=t("offset_from")).grid(row=2, column=0, sticky="w", padx=8, pady=6)
        ttk.Entry(frame_values, textvariable=self.min_var, width=15).grid(row=2, column=1, sticky="w", padx=8, pady=6)

        ttk.Label(frame_values, text=t("offset_to")).grid(row=3, column=0, sticky="w", padx=8, pady=6)
        ttk.Entry(frame_values, textvariable=self.max_var, width=15).grid(row=3, column=1, sticky="w", padx=8, pady=6)

        self.backup_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(frame_values, text=t("backup_checkbox"), variable=self.backup_var).grid(
            row=4, column=0, columnspan=2, sticky="w", padx=8, pady=6)

        ttk.Button(root, text=t("patch_button"), command=self.patch).pack(pady=10)

        frame_log = ttk.LabelFrame(root, text=t("log_frame"))
        frame_log.pack(fill="both", expand=True, **pad)
        self.log = tk.Text(frame_log, height=14, state="disabled", wrap="word")
        self.log.pack(fill="both", expand=True, padx=8, pady=8)

    def choose_files(self):
        paths = filedialog.askopenfilenames(title=t("dialog_choose_files_title"))
        for p in paths:
            if p not in self.file_paths:
                self.file_paths.append(p)
                self.file_listbox.insert("end", p)

    def clear_files(self):
        self.file_paths.clear()
        self.file_listbox.delete(0, "end")

    def log_msg(self, msg):
        self.log.configure(state="normal")
        self.log.insert("end", msg + "\n")
        self.log.configure(state="disabled")
        self.log.see("end")

    def patch(self):
        if not self.file_paths:
            messagebox.showwarning(t("no_files_title"), t("no_files_msg"))
            return

        try:
            old_pattern = parse_hex_bytes(self.old_var.get(), t("field_old_pattern"))
            new_pattern = parse_hex_bytes(self.new_var.get(), t("field_new_pattern"))
            if len(old_pattern) != len(new_pattern):
                raise ValueError(t("err_pattern_length"))
            offset_min = parse_offset(self.min_var.get(), t("field_offset_from"))
            offset_max = parse_offset(self.max_var.get(), t("field_offset_to"))
            if offset_max <= offset_min:
                raise ValueError(t("err_offset_order"))
        except ValueError as e:
            messagebox.showerror(t("invalid_input_title"), str(e))
            return

        any_success = False
        for path in self.file_paths:
            try:
                with open(path, "rb") as f:
                    data = bytearray(f.read())

                if offset_min >= len(data):
                    self.log_msg(t("log_file_too_small", path=path, size=len(data)))
                    continue

                search_end = min(offset_max, len(data))
                count = 0
                i = offset_min
                offsets = []
                while True:
                    idx = data.find(old_pattern, i, search_end)
                    if idx == -1:
                        break
                    data[idx:idx + len(old_pattern)] = new_pattern
                    offsets.append(idx)
                    count += 1
                    i = idx + len(new_pattern)

                if count == 0:
                    self.log_msg(t("log_pattern_not_found", path=path))
                    continue

                if self.backup_var.get():
                    shutil.copy2(path, path + ".bak")

                with open(path, "wb") as f:
                    f.write(data)

                offsets_str = ", ".join(f"0x{o:X}" for o in offsets)
                self.log_msg(t("log_patched", path=path, count=count, offsets=offsets_str))
                any_success = True

            except Exception as e:
                self.log_msg(t("log_error", path=path, error=e))

        if any_success:
            self.log_msg("")
            self.log_msg(t("hint_separator"))
            self.log_msg(t("hint_line1"))
            self.log_msg(t("hint_line2"))
            self.log_msg(t("hint_line3"))
            self.log_msg(t("hint_line4"))
            self.log_msg(t("hint_separator"))
            messagebox.showinfo(t("done_title"), t("done_msg_with_hint"))
        else:
            messagebox.showinfo(t("done_title"), t("done_msg_plain"))


def main():
    root = tk.Tk()
    try:
        ttk.Style().theme_use("vista")
    except tk.TclError:
        pass
    PatchApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
